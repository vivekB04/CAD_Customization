﻿using System;
using NXOpen;
using NXOpen.Features;

namespace DiceConsoleApp
{
    public class Program
    {
        // This is the Main entry point called by NX
        public static void Main(string[] args)
        {
            Session theSession = Session.GetSession();
            Part workPart = theSession.Parts.Work;

            // Open the NX Information window to show messages
            theSession.ListingWindow.Open();

            if (workPart == null)
            {
                theSession.ListingWindow.WriteLine("Error: Please open a New Part in NX first.");
                return;
            }

            DiceModeler modeler = new DiceModeler(workPart);

            double edgeLength = 100.0;  // Made it slightly larger for visibility
            double pipDiameter = 15.0;

            try
            {
                // Create cube
                Body cube = modeler.CreateCube(edgeLength);

                // Subtract pips
                modeler.CreateDicePips(cube, edgeLength, pipDiameter);

                theSession.ListingWindow.WriteLine("Dice created successfully!");
            }
            catch (Exception ex)
            {
                theSession.ListingWindow.WriteLine("Error: " + ex.Message);
            }
        }

        // REQUIRED: This tells NX to unload the DLL immediately after running.
        // Without this, you have to restart NX to make code changes.
        public static int GetUnloadOption(string dummy)
        {
            return (int)Session.LibraryUnloadOption.Immediately;
        }
    }

    public class DiceModeler
    {
        private readonly Part _workPart;

        public DiceModeler(Part part)
        {
            _workPart = part;
        }

        // Create a cube at origin
        public Body CreateCube(double edge)
        {
            BlockFeatureBuilder blockBuilder = _workPart.Features.CreateBlockFeatureBuilder(null);

            // --- FIX IS HERE ---
            // We move the origin back by half the edge length on all axes.
            // This centers the cube at 0,0,0 so your Pip math works.
            double halfEdge = edge / 2.0;
            Point3d origin3d = new Point3d(-halfEdge, -halfEdge, -halfEdge);

            blockBuilder.Origin = origin3d;

            // Set dimensions
            blockBuilder.SetOriginAndLengths(origin3d, edge.ToString(), edge.ToString(), edge.ToString());

            Feature blockFeature = blockBuilder.CommitFeature();
            blockBuilder.Destroy();

            return blockFeature.GetBodies()[0];
        }

        // Subtract a sphere from a body
        public Body SubtractSphere(Body target, Point3d pos, double diameter)
        {
            // Sphere
            SphereBuilder sb = _workPart.Features.CreateSphereBuilder(null);

            // Create a smart point for the sphere center
            Point centerPoint = _workPart.Points.CreatePoint(pos);
            sb.CenterPoint = centerPoint;

            sb.Diameter.Value = diameter;

            Feature sphereFeat = sb.CommitFeature();
            sb.Destroy();

            Body sphereBody = sphereFeat.GetBodies()[0];

            // Boolean subtract
            Body[] tools = new Body[] { sphereBody };

            // Perform the subtract
            BooleanFeature[] boolFeatures = _workPart.Features.CreateSubtractFeature(
                target, false, tools, false, false, out bool nonAssoc, out bool unparam);

            return boolFeatures[0].GetBodies()[0];
        }

        // Add all pips to cube
        public void CreateDicePips(Body cube, double edge, double pipDia)
        {
            double offset = edge / 4.0;
            double half = edge / 2.0;

            // Face 1: -Z
            cube = SubtractSphere(cube, new Point3d(0, 0, -half), pipDia);

            // Face 2: +X
            cube = SubtractSphere(cube, new Point3d(half, offset, offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(half, -offset, -offset), pipDia);

            // Face 3: +Y
            cube = SubtractSphere(cube, new Point3d(offset, half, offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(-offset, half, -offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(0, half, 0), pipDia);

            // Face 4: -Y
            cube = SubtractSphere(cube, new Point3d(offset, -half, offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(-offset, -half, offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(offset, -half, -offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(-offset, -half, -offset), pipDia);

            // Face 5: -X
            cube = SubtractSphere(cube, new Point3d(-half, offset, offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(-half, offset, -offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(-half, -offset, offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(-half, -offset, -offset), pipDia);
            cube = SubtractSphere(cube, new Point3d(-half, 0, 0), pipDia);

            // Face 6: +Z
            for (int i = -1; i <= 1; i++)
            {
                cube = SubtractSphere(cube, new Point3d(offset, i * offset, half), pipDia);
                cube = SubtractSphere(cube, new Point3d(-offset, i * offset, half), pipDia);
            }
        }
    }
}